#pragma once

#define MYICON 101
